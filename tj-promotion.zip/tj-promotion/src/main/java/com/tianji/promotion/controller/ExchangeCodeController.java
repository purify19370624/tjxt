package com.tianji.promotion.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 兑换码 前端控制器
 * </p>
 *
 * @author 虎哥
 * @since 2026-05-06
 */
@RestController
@RequestMapping("/exchange-code")
public class ExchangeCodeController {

}
